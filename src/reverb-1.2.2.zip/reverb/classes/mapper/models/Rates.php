<?php
/**
 *
 *
 * @author Johan Protin
 * @copyright Copyright (c) 2017 - Johan Protin
 * @license Apache License Version 2.0, January 2004
 * @package Reverb
 */

class Rates
{

    /**
     * @var string
     */
    public $region_code;

    /**
     * @var string
     */
    public $rate;
}
