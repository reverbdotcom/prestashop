<?php
/**
 *
 *
 * @author Johan Protin
 * @copyright Copyright (c) 2017 - Johan Protin
 * @license Apache License Version 2.0, January 2004
 * @package Reverb
 */

class Shipping
{

    /**
     * @var string
     */
    public $local;

    /**
     * @var string
     */
    public $rates;
}
